package com.java8.inerface;

public interface TestInterface {

	public void donothering();
}
