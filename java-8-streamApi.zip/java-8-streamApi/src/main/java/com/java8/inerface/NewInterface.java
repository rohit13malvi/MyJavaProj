package com.java8.inerface;

@FunctionalInterface
public interface NewInterface {

	public int getSomeValue(int t);
}
