package com.java8.model;

public class Address {
private String citry;
private long pin;
private long mobileNumber;
private String landmark;
public String getCitry() {
	return citry;
}
public void setCitry(String citry) {
	this.citry = citry;
}
public long getPin() {
	return pin;
}
public void setPin(long pin) {
	this.pin = pin;
}
public long getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(long mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public String getLandmark() {
	return landmark;
}
public void setLandmark(String landmark) {
	this.landmark = landmark;
}
@Override
public String toString() {
	return "Address [citry=" + citry + ", pin=" + pin + ", mobileNumber=" + mobileNumber + ", landmark=" + landmark
			+ "]";
}
public Address(String citry, long pin, long mobileNumber, String landmark) {
	super();
	this.citry = citry;
	this.pin = pin;
	this.mobileNumber = mobileNumber;
	this.landmark = landmark;
}

}
