//package com.java8.streamapi;
//
//import java.util.Arrays;
//import java.util.stream.Stream;
//
//public class FindOccuranceOfcharacter {
//public static void main(String[] args) {
//	String str="java is programing language";
//	char []arr=str.toCharArray();
//	
////	Stream stsr=arr;
//	Stream<char[]> sstr=Stream.of(arr);
//	
//	sstr.filter(e->e==e?count++
//}
//
//}
