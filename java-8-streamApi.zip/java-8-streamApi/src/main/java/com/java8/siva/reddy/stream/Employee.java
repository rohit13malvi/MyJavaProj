package com.java8.siva.reddy.stream;

public class Employee {
	private int empId;
	private String empName;
	private int deptId;
	private String status = "active";
	private int slary;

	public Employee(int empId, String empName, int deptId, String status, int slary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.deptId = deptId;
		this.status = status;
		this.slary = slary;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getSlary() {
		return slary;
	}

	public void setSlary(int slary) {
		this.slary = slary;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", deptId=" + deptId + ", status=" + status
				+ ", slary=" + slary + "]";
	}

}
