package com.java8.siva.reddy.stream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.stream.Collectors;

public class MainMethod {
	public static void main(String[] args) {
		List<Employee> empList = new ArrayList<>();
		empList.add(new Employee(101, "siva", 101, "active", 2000));
		empList.add(new Employee(102, "rohit", 101, "active", 5000));
		empList.add(new Employee(103, "raju", 102, "inactive", 6000));
		empList.add(new Employee(104, "ravi", 102, "inactive", 4000));
		empList.add(new Employee(105, "karan", 103, "active", 3500));
		empList.add(new Employee(106, "nitin", 103, "active", 3500));
		empList.add(new Employee(107, "sameer", 104, "active", 3500));

//1. to print emp details based on dept
		Map<Integer, List<Employee>> listOfEmpBasedOnDept = empList.stream()
				.collect(Collectors.groupingBy(Employee::getDeptId, Collectors.toList()));
		listOfEmpBasedOnDept.entrySet().forEach(entry -> {
//			System.out.println(entry.getKey() + "-------" + entry.getValue());
		});

//2. write a program to print employee count working in each department
		Map<Integer, Long> empCountBasedOnDept = empList.stream()
				.collect(Collectors.groupingBy(Employee::getDeptId, Collectors.counting()));
		empCountBasedOnDept.entrySet().forEach(e -> {
//	System.out.println(e.getKey()+"----------------"+e.getValue());
		});
//3. write a program to print active and inactive employee in  the givencollection
		List<Employee> emplistBasedOnStatus = empList.stream().filter(e -> e.getStatus().equalsIgnoreCase("inactive"))
				.collect(Collectors.toList());
//System.out.println(emplistBasedOnStatus);
		Long activeEmp = empList.stream().filter(e -> e.getStatus().equalsIgnoreCase("active")).count();
//System.out.println(activeEmp);

//4. write a program to print MAX/MIN employee salary from teh given collection
		Optional<Employee> salary = empList.stream().max(Comparator.comparing(Employee::getSlary));
//System.out.println("max Salary"+salary);
		Optional<Employee> minsalary = empList.stream().min(Comparator.comparing(Employee::getSlary));
//System.out.println("min salary"+minsalary);

//5. write a program to print the max slary of an employee from each department
		Map<Integer, Optional<Employee>> empsalaryBasdOnDept = empList.stream()
				.collect(Collectors.groupingBy(Employee::getDeptId,
						Collectors.reducing(BinaryOperator.maxBy(Comparator.comparing(Employee::getSlary)))));
		empsalaryBasdOnDept.entrySet().forEach(e -> {
			System.out.println(e.getKey() + "------" + e.getValue().get());
		});

	}
}

//1. write a program to print emplyee details working in each departhmet
//2. write a program to print employee count working in each department
//3. write a program to print active and inactive employee in  the givencollection
//4. write a program to print MAX/MIN employee salary from teh given collection
//5. write a program to print the max slary of an employee from each department