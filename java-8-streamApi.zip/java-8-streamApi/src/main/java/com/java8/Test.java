package com.java8;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.java8.inerface.NewInterface;
import com.java8.inerface.TestInterface;

public class Test {
public static void main(String[] args) {
	TestInterface t=()->System.out.println("this is lamda expression");
		t.donothering();
		NewInterface newf= (a)->  a*10;
		int result=newf.getSomeValue(5);
//		System.out.println(result);
		Function<Integer, String> fun=(name)-> "this is lamda  "+name;
//		System.out.println(fun.apply(5));
		
		List<Integer> arraylist= Arrays.asList(23,23,35,34,1);
		List<Integer> restul=arraylist.stream().map(o->o>23?o+6:o-6).sorted().collect(Collectors.toList());
		for (Integer integer : restul) {
//			System.out.println(integer);
		}
//		arraylist.stream().map(o->o>23?o+6:o-6).sorted().forEach(e->System.out.println(e));
//		arraylist.stream().map(o->o>23?o+6:o-6).sorted().forEach(System.out::println);

//		arraylist.stream().filter(u->u%2==0).forEach(System.out::print);
//		for (Integer integer : restlt1) {
////			System.out.println(integer);
//		}
		
		
		
}
}
