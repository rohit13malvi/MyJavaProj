package com.java8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java8StreamApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Java8StreamApiApplication.class, args);
	}

}
