package com.java8.dao;

import java.util.Arrays;
import java.util.List;

import com.java8.model.Address;
import com.java8.model.Employee;

public class EmpDao {
	public List<Employee> getEmp() {
	List<Employee> empList = Arrays.asList(new Employee(1, "rohit malvi", "rohit.malvi", 232323),
			new Employee(1, "rohit malvi", null, 23423), new Employee(2, "asdfasdf fg", "bcvbfv.malvi", 546345),
			new Employee(3, "fghgfv dfdf", "fsdfsd.malvi", 445),
			new Employee(4, "tynfgdfgvdf dfgd", "adsf.malvi", 5643),
			new Employee(5, "bvbdfg dfsdf", "adfas.malvi", 56345), new Employee(6, "gfbfdb", "adfd.malvi", 6545),
			new Employee(9, "rohit malvi", "rohit.malvi", 23454),
			new Employee(7, "gbdfvfdvfe", "adsfsd.malvi", 6545345),
			new Employee(8, "dfbdfbvdv", "adsfsdf.malvi", 35654643)

	);
	return empList;
	}
	
			
public List<Address> getAddress(){
	List<Address> add = Arrays.asList(new Address("aldsfj", 2323, 22323, "lkasdfj lka fdsdlf "),
			new Address("sldfjsdlf", 2323, 223454523, "lkasdfj lka fdsdlf "),
			new Address("sldkjfsl", 43545, 24454323, "dfglkasfgdfgdfj lka fdsdlf "),
			new Address("sldfjsdlf", 45645, 22454323, "lkasdfj sdfglka fdsdlf "),
			new Address("sdfkljsdf ", 345324, 24542323, null),
			new Address("dfvgdf", 34343, 22454323, "lsfdgdfgkasdfj lka fdsdlf "),
			new Address("cxvxc", 4345345, 22454323, "sfdgdglkasdfj lka fdsdlf "),
			new Address("xvxcv", 34534534, 22454323, "fghfglkasdfj lka fdsdlf ")

	);
return add;
}

}
