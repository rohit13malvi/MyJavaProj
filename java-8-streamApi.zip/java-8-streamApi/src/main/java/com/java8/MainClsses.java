package com.java8;

import java.util.List;
import java.util.stream.Collectors;

import com.java8.dao.EmpDao;
import com.java8.model.Address;
import com.java8.model.Employee;

public class MainClsses {
public static void main(String[] args) {
	EmpDao dao=new EmpDao();
	List<Employee> empList=dao.getEmp();
	List<Address> add=dao.getAddress();
	
	List<Employee> getSalary=empList.stream().filter(e->e.getSalary()>195333).collect(Collectors.toList());
//	public Stream<String> streamOf(List<String> list) {
//	    return list == null || list.isEmpty() ? Stream.empty() : list.stream();
//	}
//	if(getSalary==null||getSalary.isEmpty()||getSalary)
	for (Employee employee : getSalary) {
//		if(employee==null||employee.em)
		System.out.println(employee);
	}
}
}
