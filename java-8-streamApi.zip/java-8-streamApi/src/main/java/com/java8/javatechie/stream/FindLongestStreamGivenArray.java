package com.java8.javatechie.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FindLongestStreamGivenArray {
public static void main(String[] args) {
	String[] str= {"java","springboot","hibernate","microservies","techie","ddddoservies"};
	
	List<Integer>length=Arrays.stream(str).map(i->i.length()).collect(Collectors.toList());
	System.out.println(length );
	String longestString=
	Arrays.stream(str)
	.reduce((word1,word2)->word1.length()>word2.length()?word1:word2)
	.get();
	System.out.println(longestString);
}
}
