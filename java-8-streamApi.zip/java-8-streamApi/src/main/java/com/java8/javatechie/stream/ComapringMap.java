package com.java8.javatechie.stream;

import java.util.HashMap;
import java.util.Map;

public class ComapringMap {
public static void main(String[] args) {
	Map<String, Integer> map=new HashMap<>();
	map.put("eitht", 8);
	map.put("siven", 7);
	map.put("six", 6);
	map.put("five", 5);
	map.put("four", 4);
	map.put("three", 3);
	map.put("two", 2);
	
map.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
}
}
