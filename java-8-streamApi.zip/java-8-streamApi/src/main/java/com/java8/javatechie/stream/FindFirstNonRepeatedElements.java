package com.java8.javatechie.stream;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindFirstNonRepeatedElements {
public static void main(String[] args) {
	// ex: ilovejavatechie L is first non repeated element
	String str = "ilovejavatechie";
	//first non repeated character in string
	String firstnonrepeatedhcaracter=
Arrays.stream(str.split(""))
.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
.entrySet().stream()
.filter(i->i.getValue()==1)
.findFirst().get().getKey();
	System.out.println(firstnonrepeatedhcaracter);
	 //group by internally use hash map and hash map does not preserve insertion order
	//linkedHashMap preseve insertino order u can use hashMap

//first repeated character in given string
	String fristRepatedChacracter=
			Arrays.stream(str.split(""))
			.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
			.entrySet().stream()
			.filter(i->i.getValue()>1)
			.findFirst().get().getKey();
System.out.println(fristRepatedChacracter);
}
}
