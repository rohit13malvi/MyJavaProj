package com.java8.javatechie.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ReduceWithObject {

	public static void main(String[] args) {
		List<EmployeePojoReduceMethod> emp=new ArrayList<>();
	emp.add(new EmployeePojoReduceMethod(101, "rohit", "a", 238923));
	emp.add(new EmployeePojoReduceMethod(102, "karan", "b", 523923));
	emp.add(new EmployeePojoReduceMethod(103, "sameet", "c", 7558923));
	emp.add(new EmployeePojoReduceMethod(104, "raju", "A", 958923));
	emp.add(new EmployeePojoReduceMethod(105, "azaz", "b", 488923));
	emp.add(new EmployeePojoReduceMethod(106, "siuao", "b", 9838923));

	//get emp with grade a and average of grage a salary
//	List<EmployeePojoReduceMethod> emps = emp.stream().filter(r->r.getGrade().startsWith("a")).collect(Collectors.toList());
OptionalDouble empSalary= emp
.stream()
.filter(r->r.getGrade()
		.equalsIgnoreCase("a"))
.map(e->e.getSalary()).mapToDouble(i->i).average();

	System.out.println(empSalary.getAsDouble() );
	//sum
	double empSalarysum= emp
			.stream()
			.filter(r->r.getGrade()
					.equalsIgnoreCase("a"))
			.map(e->e.getSalary()).mapToDouble(i->i).sum();

				System.out.println(empSalarysum);
	}
}
