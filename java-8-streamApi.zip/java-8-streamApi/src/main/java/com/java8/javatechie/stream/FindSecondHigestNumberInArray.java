package com.java8.javatechie.stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class FindSecondHigestNumberInArray {
public static void main(String[] args) {
	int[] number= {3,2,4,8,3,1};
List<Integer> secondhighestNumber=	Arrays.stream(number).boxed()
	.sorted(Comparator.reverseOrder())
	.skip(1)
	.collect(Collectors.toList());
	 System.out.println(secondhighestNumber);
	 Integer secondhighestNumber1=	Arrays.stream(number).boxed()
				.sorted(Comparator.reverseOrder())
				.skip(1)
				.findFirst()
				.get();
				 System.out.println(secondhighestNumber1);
}
}
