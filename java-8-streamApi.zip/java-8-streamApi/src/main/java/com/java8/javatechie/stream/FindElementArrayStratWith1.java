package com.java8.javatechie.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FindElementArrayStratWith1 {
public static void main(String[] args) {
	//ex {2,8,1,21,8,11,2} in this 1 and 11
	int numbers[]={2,8,1,21,8,11,2};
	
	List<String> stringList=Arrays.stream(numbers)
			.boxed()
			.map(u->u+"")
			.filter(s->s.startsWith("2"))
			.collect(Collectors.toList());
	System.out.println(stringList);
	
	List<String> stringList1=Arrays.stream(numbers)
			.boxed()
			.map(u->u+"").collect(Collectors.toList());
			System.out.println(stringList1);
}
}
