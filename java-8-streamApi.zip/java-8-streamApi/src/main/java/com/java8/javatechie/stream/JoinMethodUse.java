package com.java8.javatechie.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class JoinMethodUse {
public static void main(String[] args) {
	//1-2-3-4 how to get this useing join
	//you have
	List<String> nos= Arrays.asList("1","2","3","4");
	
	String result=String.join(",", nos);
	System.out.println(result);
	
	
	//skip limit example
IntStream.rangeClosed(1, 10)
.skip(1)
.limit(8)
.forEach(System.out::println);
}
}
