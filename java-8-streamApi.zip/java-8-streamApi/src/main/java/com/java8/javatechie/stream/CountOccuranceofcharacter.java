package com.java8.javatechie.stream;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountOccuranceofcharacter {
	public static void main(String[] args) {
		String str = "javaisprograminglanguage";
//	Map<String, List<String>> map=Arrays.stream(str.split("")).collect(Collectors.groupingBy(r->r));
//System.out.println(map);
//Function.identity()-each character
		Map<String, Long> map = Arrays.stream(str.split(""))
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(map);
	}
}
