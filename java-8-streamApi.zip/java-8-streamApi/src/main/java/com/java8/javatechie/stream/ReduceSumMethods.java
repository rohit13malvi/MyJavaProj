package com.java8.javatechie.stream;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ReduceSumMethods {
	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(3, 2, 4, 1, 83, 8);
		// sum
		int num = numbers.stream().mapToInt(i -> i).sum();
		System.out.println(num);
		// reduce
		int num1 = numbers.stream().reduce(0, (a, b) -> a + b);
		System.out.println(num1);
		// reduce
		Optional<Integer> num2 = numbers.stream().reduce(Integer::sum);
		System.out .println(num2.get());
		//reduce max
	int number=	numbers.stream().reduce(0,(a,b)->a>b?a:b);
	System.out.println(number);
	//reduce max
		int numbersd=	numbers.stream().reduce(Integer::max).get();
		System.out.println(numbersd);
		//with string
		List<String> str= Arrays.asList("java","hibernate","springBoot");
	Optional<String> longString=	str.stream().reduce((word1,word2)->word1.length()>word2.length()?word1:word2);
		System.out.println(longString.get());
	}
}
