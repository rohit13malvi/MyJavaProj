package com.java8.javatechie.stream;

import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

import com.java8.model.Employee;

public class ComapringMapObject {
	public static void main(String[] args) {

		Map<Employee, Integer> empMap = new TreeMap<>((o1, o2) -> (int) (o2.getSalary() - o1.getSalary()));
		empMap.put(new Employee(176, "rohit", "it", 6000000), 60);
		empMap.put(new Employee(343, "adfff", "sdd", 56500000), 90);
		empMap.put(new Employee(453, "vbgf", "sdf", 65000000), 50);
		empMap.put(new Employee(343, "ghdf", "sdf", 34000000), 40);
		empMap.put(new Employee(543, "fhg", "fgh", 6070000), 120);
		System.out.println(empMap);

		empMap.entrySet().stream()
		.sorted(Map.Entry
				.comparingByKey(Comparator
						.comparing(Employee::getSalary).reversed()))
		.forEach(System.out::println);;
	}
}
